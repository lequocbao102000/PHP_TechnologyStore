<script src="./public/js/jquery.min.js"></script>
		<script src="./public/js/bootstrap.min.js"></script>
		<script src="./public/js/slick.min.js"></script>
		<script src="./public/js/nouislider.min.js"></script>
		<script src="./public/js/jquery.zoom.min.js"></script>
		<script src="./public/js/main.js"></script>