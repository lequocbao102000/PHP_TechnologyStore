<!-- Google font -->

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">
<?php 
        require_once ("./mvc/core/Config.php");
         
		?>
<!-- Bootstrap -->
<link type="text/css" rel="stylesheet" href="<?php echo BASE_URL?>/public/css/bootstrap.min.css"/>

<!-- Slick -->
<link type="text/css" rel="stylesheet" href="<?php echo BASE_URL?>/public/css/slick.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo BASE_URL?>/public/css/slick-theme.css"/>

<!-- nouislider -->
<link type="text/css" rel="stylesheet" href="<?php echo BASE_URL?>/public/css/nouislider.min.css"/>

<!-- Font Awesome Icon -->
<link rel="stylesheet" href="<?php echo BASE_URL?>/public/css/font-awesome.min.css">

<!-- Custom stlylesheet -->
<link type="text/css" rel="stylesheet" href="<?php echo BASE_URL?>/public/css/style.css"/>
